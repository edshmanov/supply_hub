import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Item groups (categories like "Block Paper", "DA Paper", etc.)
export const itemGroups = pgTable("item_groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  icon: text("icon").notNull().default("package"),
  sortOrder: integer("sort_order").notNull().default(0),
  isSingleItem: boolean("is_single_item").notNull().default(false),
});

export const insertItemGroupSchema = createInsertSchema(itemGroups).pick({
  name: true,
  icon: true,
  sortOrder: true,
  isSingleItem: true,
});

export type InsertItemGroup = z.infer<typeof insertItemGroupSchema>;
export type ItemGroup = typeof itemGroups.$inferSelect;

// Supply items table (variants within groups)
export const items = pgTable("items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  groupId: varchar("group_id").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  isRequested: boolean("is_requested").notNull().default(false),
  requestedAt: timestamp("requested_at"),
});

export const insertItemSchema = createInsertSchema(items).pick({
  name: true,
  groupId: true,
  sortOrder: true,
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof items.$inferSelect;

// Combined type for frontend
export type ItemGroupWithItems = ItemGroup & {
  items: Item[];
};

// Users table for manager authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Orders table for tracking submitted orders
export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  items: text("items").notNull(), // JSON string of order items
  status: text("status").notNull().default("pending"), // pending, sent, completed
  createdAt: timestamp("created_at").notNull().defaultNow(),
  sentAt: timestamp("sent_at"),
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  items: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

// Cart item type for order submission
export interface OrderItem {
  itemId: string;
  itemName: string;
  groupId: string;
  groupName: string;
}

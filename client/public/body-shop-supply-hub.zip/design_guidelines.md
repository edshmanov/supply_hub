# Body Shop Supply Hub - Design Guidelines

## Design Approach
**System**: Material Design adapted for industrial/high-visibility contexts
**Rationale**: Utility-focused application requiring efficiency, clear hierarchy, and robust touch interactions in challenging workshop conditions.

## Core Design Principles
1. **High Visibility First**: Maximum contrast and legibility from 3+ feet away
2. **Touch-Optimized**: All interactive elements ≥48px, accounting for gloved hands
3. **Minimal Cognitive Load**: Clear visual states, immediate feedback
4. **Industrial Durability**: Design assumes dirty hands, bright overhead lighting, quick glances

---

## Typography

**Font Family**: Inter (via Google Fonts)
- Primary: Inter (all weights)
- Fallback: system-ui, sans-serif

**Hierarchy**:
- H1 (Page Titles): text-4xl, font-bold (36px) - Technician/Manager view headers
- H2 (Category Headers): text-2xl, font-semibold (24px) - "Abrasives", "Chemicals"
- Body (Item Names): text-xl, font-medium (20px) - "Sandpaper 80 grit"
- Labels/Metadata: text-sm, font-normal (14px) - Timestamps, counts
- Buttons: text-lg, font-semibold (18px) - All CTAs

---

## Layout System

**Spacing Units**: Tailwind 4, 6, 8, 12, 16 (consistent vertical rhythm)
- Component padding: p-6
- Section gaps: gap-8
- Card spacing: space-y-4
- Touch target minimum: p-4

**Grid Structure**:
- Technician View: Single column list (max-w-4xl centered)
- Manager Dashboard: Two-column split on tablet landscape (grid-cols-2)
- Category groups: Stack vertically with clear dividers

**Container Strategy**:
- Full viewport utilization (no floating elements)
- Safe area padding: px-6 for tablet edges
- Scrollable content areas with sticky headers

---

## Component Library

### Navigation/Header
- Fixed top bar (h-16) with app title + current view indicator
- Manager view: Add "Clear All Requests" action in header
- No hamburger menu needed - single-screen focused design

### Item Cards (Technician Interface)
- Full-width touch targets (w-full, min-h-20)
- Left: Item name + quantity indicator
- Right: Large "Request Restock" button or status badge
- Visual states:
  - Default: Subtle border, light background
  - Requested: Bold accent border, "REQUESTED" badge prominent
  - Recently added: Brief highlight animation (1s fade)

### Buttons
- Primary CTA: Large rounded buttons (rounded-xl, px-8, py-4)
- Request buttons: Full height of card row for maximum tap area
- Status badges: rounded-full, px-4, py-2, uppercase text

### Manager Dashboard Components
- Request Queue: Scrollable list with timestamps
- Item count badge in header showing total pending
- Bulk actions: "Clear All" + individual "Mark Ordered" per item
- Timestamp format: "2 hours ago" (relative time)

### Forms (Add New Item - Admin)
- Large input fields (h-14)
- Dropdown category selector (touch-optimized)
- Submit button: Full-width, prominent

### Icons (Lucide React)
- Package icon for inventory items
- AlertCircle for requested status
- CheckCircle for completed orders
- Plus for add new item
- Lock for manager access

---

## Interaction Patterns

**Touch Feedback**: All buttons show immediate visual press state (scale-95 active state)

**State Management**:
- Requested items: Persist bold visual treatment until cleared
- Real-time sync: Show subtle pulse when list updates
- Loading states: Skeleton placeholders during data fetch

**Accessibility**:
- High contrast ratios (WCAG AAA for core UI)
- No hover-dependent interactions (touch-first)
- Large tap targets throughout (minimum 48x48px)
- Clear focus indicators for keyboard navigation

---

## Visual Treatment

**Dark Mode Industrial Theme**:
- Deep neutral backgrounds (not pure black - easier on eyes)
- High-contrast text (crisp white/light gray on dark)
- Accent color for active requests: Bright amber/orange (high visibility)
- Success states: Vibrant green
- Dividers: Subtle light borders for section separation

**Elevation/Depth**:
- Minimal shadows (industrial spaces have overhead lighting)
- Use borders instead of shadows for card definition
- Subtle background variations for component hierarchy

---

## Tablet Optimization

**Landscape Orientation** (primary):
- Two-column manager dashboard
- Horizontal category tabs if needed

**Portrait Orientation**:
- Stack everything single-column
- Maintain same touch target sizes
- Sticky category headers while scrolling

**Safe Areas**: Account for tablet bezels/mounting hardware with generous edge padding

---

## Images
**Not applicable** - This is a pure utility application. All visual communication through typography, icons, and color-coded states. No hero images or decorative photography needed.
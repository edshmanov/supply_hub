import type { FC } from "react";

interface IconProps {
  className?: string;
}

export function BlockPaperIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="8" y="12" width="32" height="24" rx="2" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M8 20H40" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M8 28H40" stroke="currentColor" strokeWidth="1.5"/>
      <circle cx="14" cy="16" r="1.5" fill="currentColor"/>
      <circle cx="20" cy="16" r="1.5" fill="currentColor"/>
      <circle cx="26" cy="16" r="1.5" fill="currentColor"/>
      <circle cx="14" cy="24" r="1.5" fill="currentColor"/>
      <circle cx="20" cy="24" r="1.5" fill="currentColor"/>
      <circle cx="26" cy="24" r="1.5" fill="currentColor"/>
      <circle cx="14" cy="32" r="1.5" fill="currentColor"/>
      <circle cx="20" cy="32" r="1.5" fill="currentColor"/>
      <circle cx="26" cy="32" r="1.5" fill="currentColor"/>
    </svg>
  );
}

export function ScuffRollIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="16" cy="24" rx="8" ry="14" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <ellipse cx="16" cy="24" rx="3" ry="5" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      <path d="M16 10C28 10 38 14 38 24C38 34 28 38 16 38" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M38 24L42 20M38 24L42 28" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );
}

export function DAPaperIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="24" cy="24" r="16" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <circle cx="24" cy="24" r="4" stroke="currentColor" strokeWidth="2" fill="none"/>
      <circle cx="24" cy="12" r="1.5" fill="currentColor"/>
      <circle cx="24" cy="36" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="24" r="1.5" fill="currentColor"/>
      <circle cx="36" cy="24" r="1.5" fill="currentColor"/>
      <circle cx="16" cy="16" r="1" fill="currentColor"/>
      <circle cx="32" cy="16" r="1" fill="currentColor"/>
      <circle cx="16" cy="32" r="1" fill="currentColor"/>
      <circle cx="32" cy="32" r="1" fill="currentColor"/>
    </svg>
  );
}

export function PrimerIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="14" y="16" width="20" height="26" rx="2" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <rect x="18" y="6" width="12" height="10" rx="1" stroke="currentColor" strokeWidth="2" fill="none"/>
      <path d="M22 6V4C22 3 22.5 2 24 2C25.5 2 26 3 26 4V6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <rect x="17" y="22" width="14" height="8" rx="1" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      <path d="M19 26H29" stroke="currentColor" strokeWidth="1"/>
    </svg>
  );
}

export function FillerIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="24" cy="36" rx="14" ry="6" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M10 36V20C10 14 16 10 24 10C32 10 38 14 38 20V36" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <ellipse cx="24" cy="20" rx="14" ry="6" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M16 20C16 18 19 16 24 16C29 16 32 18 32 20" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  );
}

export function GlazeIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M14 40L10 16H38L34 40H14Z" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <rect x="8" y="10" width="32" height="6" rx="1" stroke="currentColor" strokeWidth="2" fill="none"/>
      <path d="M18 24C18 22 20 20 24 20C28 20 30 22 30 24" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <path d="M16 32H32" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  );
}

export function WaxGreaseIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="12" y="18" width="24" height="24" rx="2" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M20 18V12C20 10 21 8 24 8C27 8 28 10 28 12V18" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M18 26L22 30L30 22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

export function LacquerIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="14" y="14" width="20" height="28" rx="2" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <rect x="20" y="6" width="8" height="8" rx="1" stroke="currentColor" strokeWidth="2" fill="none"/>
      <circle cx="24" cy="10" r="2" fill="currentColor"/>
      <path d="M18 22H30" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M18 28H30" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M18 34H26" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  );
}

export function TapeIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="24" cy="24" r="14" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <circle cx="24" cy="24" r="6" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M38 24H44" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M44 18L44 30" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );
}

export function PlasticSheetIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 10H32L40 18V38H8V10Z" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M32 10V18H40" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M14 22H34" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 2"/>
      <path d="M14 28H34" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 2"/>
      <path d="M14 34H26" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 2"/>
    </svg>
  );
}

export function SprayCanIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="14" y="18" width="20" height="26" rx="3" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <rect x="18" y="8" width="12" height="10" rx="1" stroke="currentColor" strokeWidth="2" fill="none"/>
      <circle cx="24" cy="4" r="2" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      <path d="M24 6V8" stroke="currentColor" strokeWidth="1.5"/>
      <circle cx="24" cy="32" r="6" stroke="currentColor" strokeWidth="2" fill="none"/>
      <circle cx="24" cy="32" r="2" fill="currentColor"/>
    </svg>
  );
}

export function PartsIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 24C8 16 12 8 24 8" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
      <path d="M24 8C36 8 40 16 40 24" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
      <rect x="6" y="22" width="36" height="18" rx="2" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <circle cx="14" cy="40" r="4" stroke="currentColor" strokeWidth="2" fill="none"/>
      <circle cx="34" cy="40" r="4" stroke="currentColor" strokeWidth="2" fill="none"/>
      <path d="M12 28H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M28 28H36" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );
}

export function GlovesIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 42V26L12 20V12C12 10 13 8 15 8C17 8 18 10 18 12V22" stroke="currentColor" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
      <path d="M18 22V8C18 6 19 4 21 4C23 4 24 6 24 8V22" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M24 22V6C24 4 25 2 27 2C29 2 30 4 30 6V22" stroke="currentColor" strokeWidth="2.5" fill="none"/>
      <path d="M30 22V10C30 8 31 6 33 6C35 6 36 8 36 10V26L32 42H16" stroke="currentColor" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
      <path d="M16 34H32" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  );
}

export function WishlistIcon({ className }: IconProps) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M24 42L10 28C6 24 6 18 10 14C14 10 20 10 24 14C28 10 34 10 38 14C42 18 42 24 38 28L24 42Z" stroke="currentColor" strokeWidth="2.5" fill="none" strokeLinejoin="round"/>
      <path d="M20 22L24 26L32 18" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

export const categoryIconMap: Record<string, FC<IconProps>> = {
  "block-paper": BlockPaperIcon,
  "scuff-roll": ScuffRollIcon,
  "da-paper": DAPaperIcon,
  "primer": PrimerIcon,
  "filler": FillerIcon,
  "glaze": GlazeIcon,
  "wax-grease": WaxGreaseIcon,
  "lacquer": LacquerIcon,
  "tape": TapeIcon,
  "plastic-sheet": PlasticSheetIcon,
  "spray-can": SprayCanIcon,
  "parts": PartsIcon,
  "gloves": GlovesIcon,
  "wishlist": WishlistIcon,
};

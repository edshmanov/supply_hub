import { ArrowLeft, Check, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { useCart } from "@/providers/cart-provider";
import type { ItemGroupWithItems, Item, ItemGroup } from "@shared/schema";

interface VariantSelectorProps {
  group: ItemGroupWithItems | null;
  open: boolean;
  onClose: () => void;
  onAddToCart: (item: Item, group: ItemGroup) => void;
}

export function VariantSelector({ 
  group, 
  open, 
  onClose, 
  onAddToCart,
}: VariantSelectorProps) {
  const { isInCart } = useCart();
  
  if (!group) return null;

  return (
    <Sheet open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <SheetContent 
        side="bottom" 
        className="h-[85vh] rounded-t-3xl bg-background border-t-2 border-border [&>button:last-of-type]:hidden"
      >
        <SheetHeader className="pb-6 border-b border-border">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onClose}
              data-testid="button-close-variants"
              className="h-10 w-10"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <SheetTitle className="text-2xl font-bold">{group.name}</SheetTitle>
          </div>
          <p className="text-muted-foreground text-lg ml-13">
            Select items to add to your order
          </p>
        </SheetHeader>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 py-6 overflow-y-auto max-h-[calc(85vh-140px)]">
          {group.items.map((item) => (
            <VariantButton
              key={item.id}
              item={item}
              groupName={group.name}
              isInCart={isInCart(item.id)}
              onAdd={() => onAddToCart(item, group)}
            />
          ))}
        </div>
      </SheetContent>
    </Sheet>
  );
}

interface VariantButtonProps {
  item: Item;
  groupName: string;
  isInCart: boolean;
  onAdd: () => void;
}

function VariantButton({ item, groupName, isInCart, onAdd }: VariantButtonProps) {
  return (
    <button
      data-testid={`variant-button-${item.id}`}
      onClick={() => !isInCart && onAdd()}
      disabled={isInCart}
      className={`
        flex flex-col items-center justify-center gap-3
        min-h-[120px] p-6 rounded-2xl border-2 transition-all
        text-center
        ${isInCart 
          ? "border-primary bg-primary/10 cursor-default" 
          : "border-border bg-card hover:bg-card/80 active:scale-95"
        }
      `}
    >
      {isInCart ? (
        <>
          <div className="p-3 rounded-full bg-primary/20">
            <Check className="w-8 h-8 text-primary" />
          </div>
          <span className="text-xl font-bold">{item.name}</span>
          <Badge className="bg-primary text-primary-foreground">
            <ShoppingCart className="w-3 h-3 mr-1" />
            In Cart
          </Badge>
        </>
      ) : (
        <>
          <span className="text-3xl font-bold">{item.name}</span>
          <span className="text-sm text-muted-foreground">
            Tap to add
          </span>
        </>
      )}
    </button>
  );
}
